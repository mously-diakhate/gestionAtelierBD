package couture.exe.services;


import couture.exe.entities.Categorie;

public interface CategorieService extends IService<Categorie>{
    
    
}
