package couture.exe.services;
import couture.exe.entities.ArticleConfection;

public interface ArticleConfectionService extends IService<ArticleConfection>{
    
}
