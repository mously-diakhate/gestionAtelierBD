package couture.exe.repositories.BaseDeDonnes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import couture.exe.entities.Categorie;
import couture.exe.repositories.ITables;

public class CategorieRepository extends MySql implements ITables<Categorie> {

    public CategorieRepository() {
        // Utilisez la méthode connect pour établir la connexion à la base de données
        connect("jdbc:mysql://localhost:3306/votre_base_de_donnees", "root", "");
    }

    @Override
    public int delete(int id) {
        String sql = "DELETE FROM `nom_de_votre_table` WHERE `id` = ?";
        return executeUpdate(sql, id);
    }

    @Override
    public ArrayList<Categorie> findAll() {
        ArrayList<Categorie> categories = new ArrayList<>();
        String sql = "SELECT id, libelle FROM `nom_de_votre_table`";
        ResultSet rs = executeSelect(sql);
        try {
            while (rs.next()) {
                Categorie categorie = new Categorie(rs.getInt("id"), rs.getString("libelle"));
                categories.add(categorie);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }

    @Override
    public Categorie findById(int id) {
        Categorie categorie = null;
        String sql = "SELECT id, libelle FROM `nom_de_votre_table` WHERE `id` = ?";
        ResultSet rs = executeSelect(sql, id);
        try {
            if (rs.next()) {
                categorie = new Categorie(rs.getInt("id"), rs.getString("libelle"));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categorie;
    }

    @Override
    public int indexOf(int id) {
        return -1;
    }

    @Override
    public int insert(Categorie data) {
        String sql = "INSERT INTO `nom_de_votre_table` (`libelle`) VALUES (?)";
        return executeUpdate(sql, data.getLibelle());
    }

    @Override
    public int update(Categorie data) {
        String sql = "UPDATE `nom_de_votre_table` SET `libelle` = ? WHERE `id` = ?";
        return executeUpdate(sql, data.getLibelle(), data.getId());
    }
}
