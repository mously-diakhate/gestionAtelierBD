package couture.exe.repositories.List;

import couture.exe.entities.ArticleConfection;
public class TableArticleConfection extends Table <ArticleConfection>{
   
}
