package couture.exe.repositories.List;

import couture.exe.entities.Categorie;

public class TableCategorie extends Table <Categorie>{

    
    
}
