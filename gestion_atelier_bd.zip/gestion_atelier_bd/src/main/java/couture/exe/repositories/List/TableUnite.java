package couture.exe.repositories.List;

import couture.exe.entities.Unite;

public class TableUnite extends Table<Unite>{


}
